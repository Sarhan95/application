import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report,f1_score
from sklearn.model_selection import learning_curve
from sklearn.ensemble import RandomForestClassifier


def main():
    st.title("application machine learning de detection card fraud")
    st.subheader("auteur:zakaria sarhan")
    ######### importation des données
    @st.cache_data(persist=True)
    def load_data():
        data=pd.read_csv("C:/Users/hp/Desktop/creditcard.csv")
        return data
    ####### affichage notre data
    df=load_data()
    df_sample=df.sample(100)
    if st.sidebar.checkbox("afficher les jeu de données : echantillion 100",False):
          st.subheader("jeu de données crdit card bancaire")
          st.write(df_sample)



        ######## division notre dataset
    seed=123


    @st.cache_data(persist=True)
    def split(df):
        y = df["Class"]
        x = df.drop("Class", axis=1)
        x_train, x_test, y_train, y_test = train_test_split(
            x, y,
            test_size=0.2,
            random_state=seed

        )


    x_train,x_test,y_train,y_test=split(df)






    classifier=st.sidebar.selectbox("classification",
                                        ("random forest", "regression logistique")
    )











if __name__ == '__main__':

    main()
